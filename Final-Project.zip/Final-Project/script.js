function validateLoginForm() {
    var username = document.forms["loginForm"]["username"].value;
    var password = document.forms["loginForm"]["password"].value;

    if (username === "") {
        alert("Please enter your username.");
        return false;
    }
    if (password === "") {
        alert("Please enter your password.");
        return false;
    }
    return true;
}

function validateRegistrationForm() {
    var username = document.forms["registrationForm"]["username"].value;
    var password = document.forms["registrationForm"]["password"].value;
    var confirmPassword = document.forms["registrationForm"]["confirmPassword"].value;

    if (username === "") {
        alert("Please enter a username.");
        return false;
    }
    if (password === "") {
        alert("Please enter a password.");
        return false;
    }
    if (confirmPassword === "") {
        alert("Please confirm your password.");
        return false;
    }
    if (password !== confirmPassword) {
        alert("Passwords do not match.");
        return false;
    }
    return true;
}

function validateWelcomePage() {
    var isLoggedIn = true; // Your logic to check if user is logged in
    if (!isLoggedIn) {
        alert("Please login first.");
        window.location.href = "index.html";
        return false;
    }
    return true;
}

function showMessage(message) {
    var popup = document.getElementById("messagePopup");
    var messageText = document.getElementById("messageText");

    messageText.innerHTML = message;
    popup.style.display = "block";

    setTimeout(function() {
        popup.style.display = "none";
    }, 3000);
}

function handleSuccessfulLogin() {
    showMessage("Login successful!");
    window.location.href = "WelcomePage.php";
}

function handleSuccessfulRegistration() {
    showMessage("Registration successful!");
    setTimeout(function() {
        window.location.href = "index.html";
    }, 3000);
}

function handleIncorrectCredentials() {
    showMessage("Incorrect credentials. Please try again.");
}

function handleLogin() {
    if (validateLoginForm()) {
        return true; // Allow form submission
    }
    return false; // Prevent default form submission
}

function handleRegistration() {
    if (validateRegistrationForm()) {
        return true; // Allow form submission
    }
    return false; // Prevent default form submission
}
