<?php
$host = 'localhost';
$db = 'user_db';
$user = 'root';
$pass = '';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_POST['username'];
$password = $_POST['password'];
$confirmPassword = $_POST['confirmPassword'];

if ($password != $confirmPassword) {
    echo '<script>alert("Passwords do not match."); window.location.href = "SignUp.php";</script>';
    exit();
}

$hashed_password = password_hash($password, PASSWORD_DEFAULT);

$sql = "INSERT INTO users (username, password) VALUES (?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $username, $hashed_password);

if ($stmt->execute()) {
    echo '<script>alert("Registration successful!"); window.location.href = "index.html";</script>';
} else {
    echo '<script>alert("Error: ' . $stmt->error . '"); window.location.href = "SignUp.php";</script>';
}

$conn->close();
?>
