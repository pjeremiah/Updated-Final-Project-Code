<?php
session_start();

if (!isset($_SESSION['username'])) {
    echo '<script>alert("Please log in first."); window.location.href = "index.html";</script>';
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome Page</title>
    <link rel="stylesheet" href="style.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: "Poppins", sans-serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f2f2f2;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
            width: 100%;
            padding: 20px; /* Add padding for spacing */
        }

        .welcome-box {
            display: flex;
            flex-direction: column; /* Column for mobile-first approach */
            width: 100%;
            max-width: 900px; /* Adjust to match other pages */
            height: 450px; /* Adjust to match other pages */
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            background-color: #fff;
        }

        .welcome-message {
            background-color: #fff;
            padding: 20px; /* Adjust padding */
            width: 100%; /* Make it full-width for mobile */
            text-align: center;
            position: relative;
            display: flex; /* Apply Flexbox */
            flex-direction: column; /* Stack children vertically */
            justify-content: center; /* Center children vertically */
            align-items: center; /* Center children horizontally */
            height: 100%; /* Make it take full height of the container */
        }

        .image-container {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('pic.png');
            background-size: cover;
            background-position: center;
            opacity: 0.2;
        }

        .welcome-message h2,
        .welcome-message p {
            position: relative;
            z-index: 1;
        }

        .get-started {
            background-color: #333;
            padding: 20px; /* Adjust padding */
            width: 100%; /* Make it full-width for mobile */
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
        }

        .get-started img {
            width: 100px;
            height: 100px;
            margin-bottom: 20px;
            object-fit: cover;
        }

        .get-started .btn {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 10px 20px;
            background-color: #fff;
            color: #333;
            border: none;
            border-radius: 30px;
            cursor: pointer;
            font-size: 16px;
            text-decoration: none;
        }

        .get-started .btn:hover {
            background-color: #eee;
        }

        .get-started .btn span {
            margin-left: 10px;
        }

        /* Media Queries for larger screens */
        @media (min-width: 768px) {
            .welcome-box {
                flex-direction: row; /* Change to row for larger screens */
            }

            .welcome-message {
                width: 50%;
                padding: 40px; /* Increase padding */
            }

            .get-started {
                width: 50%;
                padding: 40px; /* Increase padding */
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="welcome-box">
            <div class="welcome-message">
                <div class="image-container"></div>
                <h2>Hi, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h2>
                <p>Welcome to SneakPeak!</p>
            </div>
            <div class="get-started">
                <img src="image-placeholder.png" alt="Image">
                <button class="btn">Get started <span>→</span></button>
            </div>
        </div>
    </div>
</body>
<script src="script.js"></script>
</html>
